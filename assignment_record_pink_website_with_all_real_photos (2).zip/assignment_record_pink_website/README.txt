ASSIGNMENT & RECORDS — PINK WEBSITE

Files:
- index.html
- style.css
- script.js
- config.js
- assets/profile.png

HOW TO USE:
1. Keep all files/folders together.
2. Open the folder in VS Code.
3. Right-click index.html -> Open with Live Server.
4. The website opens in Chrome.
5. Edit config.js if you want to change the WhatsApp number or prices.
6. Edit index.html for wording.
7. Replace sample cards with your own real work photos when ready.

WHATSAPP:
The form calculates the estimated price and opens WhatsApp with the order details already filled in.

IMPORTANT:
The website does not process online payments. It only prepares an order message for WhatsApp.
