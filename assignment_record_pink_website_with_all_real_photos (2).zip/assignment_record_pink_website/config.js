const BUSINESS_CONFIG = {
  whatsappNumber: "918106060398",
  prices: {
    assignment: 15,
    record: 20,
    project: 30,
    notes: 15
  },
  urgentFee: 15,
  currency: "₹"
};
