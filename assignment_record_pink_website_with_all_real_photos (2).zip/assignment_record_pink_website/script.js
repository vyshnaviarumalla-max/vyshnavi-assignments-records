(function(){
  const cfg = BUSINESS_CONFIG;
  const form = document.getElementById('orderForm');
  const pages = document.getElementById('pages');
  const service = document.getElementById('service');
  const urgent = document.getElementById('urgent');
  const total = document.getElementById('total');

  function calculate(){
    const count = Math.max(1, Number(pages.value) || 1);
    const base = (cfg.prices[service.value] || 0) * count;
    const extra = urgent.value === 'yes' ? cfg.urgentFee : 0;
    total.textContent = `${cfg.currency}${base + extra}`;
    return base + extra;
  }

  function waUrl(message){
    return `https://wa.me/${cfg.whatsappNumber}?text=${encodeURIComponent(message)}`;
  }

  document.querySelectorAll('[data-wa-link]').forEach(a => {
    a.addEventListener('click', e => {
      if(a.getAttribute('href') === '#order') return;
      e.preventDefault();
      window.open(waUrl('Hi! I want to place an order for assignment/record writing. Please share the details.'), '_blank');
    });
  });

  [pages, service, urgent].forEach(el => el.addEventListener('input', calculate));
  [service, urgent].forEach(el => el.addEventListener('change', calculate));

  form.addEventListener('submit', e => {
    e.preventDefault();
    const data = new FormData(form);
    const serviceNames = {assignment:'Assignment',record:'Record',project:'Project',notes:'Notes'};
    const amount = calculate();
    const message = `📚 NEW ORDER — ASSIGNMENT & RECORDS

👤 Name: ${data.get('name')}
🏫 College / University: ${data.get('college')}
📘 Subject: ${data.get('subject')}
✍️ Service: ${serviceNames[data.get('service')]}
📄 Pages: ${data.get('pages')}
📅 Deadline: ${data.get('deadline') || 'Not specified'}
⚡ Urgent: ${data.get('urgent') === 'yes' ? 'Yes' : 'No'}
💰 Estimated price: ${cfg.currency}${amount}

📝 Extra instructions:
${data.get('notes') || 'None'}

Please confirm availability, final price and delivery details. ♡`;
    window.open(waUrl(message), '_blank');
  });

  calculate();

  // Tap any real-work photo to view it larger.
  const modal = document.createElement('div');
  modal.className = 'photo-modal';
  modal.innerHTML = '<button class="close-modal" aria-label="Close">×</button><img alt="Handwritten work"><div class="modal-caption"></div>';
  document.body.appendChild(modal);
  const modalImg = modal.querySelector('img');
  const modalCaption = modal.querySelector('.modal-caption');
  const closeModal = () => modal.classList.remove('open');
  document.querySelectorAll('.photo-card img').forEach(img => {
    img.addEventListener('click', () => {
      modalImg.src = img.src;
      modalImg.alt = img.alt;
      modalCaption.textContent = img.closest('.photo-card').querySelector('figcaption').textContent;
      modal.classList.add('open');
    });
  });
  modal.querySelector('.close-modal').addEventListener('click', closeModal);
  modal.addEventListener('click', e => { if(e.target === modal) closeModal(); });
  document.addEventListener('keydown', e => { if(e.key === 'Escape') closeModal(); });
})();
